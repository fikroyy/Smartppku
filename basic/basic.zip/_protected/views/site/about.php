<?php

/* @var $this yii\web\View */

use yii\helpers\Html;
$this->title = 'About Us';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
    	<font size="4", >Mau tau?
    		<a href="http://ppku.ipb.ac.id/">Klik Disini!
    	</font>
        
    </p>
<!-- 
    <code><?= __FILE__ ?></code> -->
</div>
